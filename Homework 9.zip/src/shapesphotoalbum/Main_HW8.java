package shapesphotoalbum;

/**
 * Main class used to display an example of the programming running.
 */
public class Main_HW8 {
  /**
   * The entry point of application.
   *
   * @param args the input arguments
   */
  /*public static void main(String[] args) {
    StringBuilder log = new StringBuilder();
    PhotoAlbumModel model = new PhotoAlbumModel(log);
    double[] position1 = new double[2];
    position1[0] = 12;
    position1[1] = -40;
    IShape oval = model.createShape("oval", "O", Color.BLUE, position1, 25, 15);
    double[] position2 = new double[2];
    position2[0] = -52;
    position2[1] = 0;
    IShape rec = model.createShape("rectangle", "R", Color.GREEN, position2, 8, 21);
    model.snapshot("First snapshot!");
    model.changeWidth((Rectangle)rec, 15);
    model.changeColor(oval, Color.RED);
    model.scaleShape(oval, 120);
    model.snapshot("Second snapshot!");
    model.printSnapshots();
    System.out.println(log);
  }*/
}
